function updateClock(){
let d=new Date();
clock.textContent=d.toLocaleTimeString('sv-SE',{hour:'2-digit',minute:'2-digit'});
date.textContent=d.toLocaleDateString('sv-SE',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
nameDay.textContent='🌸 Namnsdag: '+Calendar.getName();
}
updateClock();setInterval(updateClock,1000);Weather.start();
