const Weather={
async start(){
let url=`https://api.open-meteo.com/v1/forecast?latitude=${CONFIG.lat}&longitude=${CONFIG.lon}&current=temperature_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=Europe/Helsinki`;
let d=await fetch(url).then(r=>r.json());
document.getElementById('weather').innerHTML=`<div class="icon">🌤️</div><div class="temp">${Math.round(d.current.temperature_2m)}°C</div><p>Helsingfors</p><p>Vind ${Math.round(d.current.wind_speed_10m)} km/h</p>`;
let html='<h2>5 DAGARS PROGNOS</h2><div class="days">';
for(let i=0;i<5;i++){html+=`<div class="day">${new Date(d.daily.time[i]).toLocaleDateString('sv-SE',{weekday:'short'})}<div class="icon">🌤️</div><b>${Math.round(d.daily.temperature_2m_max[i])}°</b><br>${Math.round(d.daily.temperature_2m_min[i])}°</div>`}
html+='</div>';
document.getElementById('forecast').innerHTML=html;
}}
